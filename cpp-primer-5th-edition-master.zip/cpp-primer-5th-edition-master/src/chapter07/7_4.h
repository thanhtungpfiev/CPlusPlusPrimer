#ifndef _7_4_H
#define _7_4_H

#include <string>

struct Person {
    std::string name;
    std::string address;
};

#endif //_7_4_H