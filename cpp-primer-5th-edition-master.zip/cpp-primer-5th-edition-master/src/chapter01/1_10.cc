#include <iostream>

int main()
{
    int i = 10;
    while (i >= 0)
        std::cout << i-- << " ";
    return 0;
}