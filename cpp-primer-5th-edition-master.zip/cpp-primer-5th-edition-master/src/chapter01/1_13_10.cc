#include <iostream>

int main()
{
    for (int i = 10; i >= 0; i--)
        std::cout << i << " ";
    return 0;
}