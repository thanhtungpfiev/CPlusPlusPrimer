#include <iostream>

int main()
{
    std::cout << "2" << "\115\n";
    std::cout << 2 << "\t\115\n";

    return 0;
}