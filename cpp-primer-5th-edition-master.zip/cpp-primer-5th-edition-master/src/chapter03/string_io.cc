#include <iostream>
#include <string>

using std::string;
using std::cin;
using std::cout;
using std::endl;

int main()
{
    string s;
    cin >> s;
    cout << s << endl;

    string s1, s2;
    cin >> s1 >> s2;
    cout << s1 << s2 << endl;

    return 0;
}