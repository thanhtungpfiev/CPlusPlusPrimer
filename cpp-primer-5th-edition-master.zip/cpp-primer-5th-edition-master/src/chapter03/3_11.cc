#include <string>
using std::string;

int main()
{
    string s = "Keep out!";

    for (auto &c : s) { // c is const char&

    }

    return 0;
}