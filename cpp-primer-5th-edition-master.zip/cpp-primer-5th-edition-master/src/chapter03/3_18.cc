#include <vector>
using std::vector;

int main()
{
    vector<int> ivec;
    ivec.push_back(42);

    return 0;
}