#include <iostream>
using std::endl; using std::cin; using std::cout;

#include <exception>

int main()
{
    int ia, ib;
    cin >> ia >> ib;
    cout << ia / ib << endl;

    return 0;
}